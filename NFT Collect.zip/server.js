const express = require("express");
const app = express();
const expbs = require("express-handlebars");

app.engine("handlebars", expbs({ defaultLayout: "main" }));
app.set("view engine", "handlebars");

app.use(express.static("public"));

// routing
app.get("/", (req, res) => {
  res.render("index", {
    title: "Sign in",
    style: "style.css",
  });
});

app.get("/signup", (req, res) => {
  res.render("signup", {
    title: "Sign up",
    style: "style.css",
  });
});

app.get("/feed", (req, res) => {
  res.render("feed", {
    title: "feed",
    style: "feed.css",
    exStyle: "https://unicons.iconscout.com/release/v2.1.6/css/unicons.css",
    script: "index.js"
  });
});


app.listen(3001, () => {
  console.log("Server is starting at port", 3001);
});
